import { Opportunity } from './opportunity.model';

describe('Opportunity', () => {
  it('should create an instance', () => {
    expect(new Opportunity()).toBeTruthy();
  });
});
